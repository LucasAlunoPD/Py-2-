Crie aqui seu ambiente virtual (venv) para o projeto microblog.
