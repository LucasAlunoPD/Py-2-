"""
Módulo com funções auxiliares de acesso ao banco (CRUD).
"""

from typing import Optional, List

from app import db
from app.models.models import User, Post


def create_user(username: str, email: str, password: str,
                profile_image: Optional[str] = None,
                bio: Optional[str] = None) -> User:
    user = User(username=username, email=email,
                profile_image=profile_image, bio=bio)
    user.set_password(password)
    db.session.add(user)
    db.session.commit()
    return user


def get_user_by_username(username: str) -> Optional[User]:
    return User.query.filter_by(username=username).first()


def create_post(body: str, user: User) -> Post:
    post = Post(body=body, author=user)
    db.session.add(post)
    db.session.commit()
    return post


def get_timeline(limit: int = 5) -> List[Post]:
    return (
        Post.query
        .order_by(Post.timestamp.desc())
        .limit(limit)
        .all()
    )
