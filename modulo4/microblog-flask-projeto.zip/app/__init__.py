import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = "main.login"


def create_app():
    """Fábrica de aplicação Flask."""
    app = Flask(__name__, instance_relative_config=True)

    # Configuração básica
    app.config.from_mapping(
        SECRET_KEY="dev",  # troque em produção
        SQLALCHEMY_DATABASE_URI="sqlite:///" + os.path.join(app.instance_path, "microblog.db"),
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
    )

    # Garante que a pasta instance exista
    try:
        os.makedirs(app.instance_path, exist_ok=True)
    except OSError:
        pass

    # Inicializa extensões
    db.init_app(app)
    login_manager.init_app(app)

    # Importa modelos para criar as tabelas
    from app.models.models import User, Post  # noqa: F401

    with app.app_context():
        db.create_all()

    # Registra rotas (blueprint)
    from app.routes import bp as main_bp
    app.register_blueprint(main_bp)

    return app
