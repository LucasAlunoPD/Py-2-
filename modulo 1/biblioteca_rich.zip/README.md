# Exercício Biblioteca Rich

## Passos para rodar

1. Criar ambiente virtual:
```bash
python -m venv venv
```

2. Ativar o ambiente:
- Windows: `venv\Scripts\activate`
- Linux/Mac: `source venv/bin/activate`

3. Instalar dependência:
```bash
pip install rich
```

4. Executar exemplos:
```bash
python main.py "Olá Lucas" -m painel -f painel_basico
python main.py texto.txt -a -m estilo -f estilo_azul
```

5. Gerar documentação:
```bash
pydoc -w personalizador
```
