"""
Pacote personalizador
Agrupa diferentes módulos que usam a biblioteca Rich.
"""
