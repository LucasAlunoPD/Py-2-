"""
Módulo progresso - uso do Rich Progress para exibir progresso.
"""

import time
from rich.progress import Progress

def progresso_rapido(texto: str, isArquivo: bool = False) -> None:
    """
    Simula uma barra de progresso rápida antes de mostrar o texto.
    """
    conteudo = open(texto, encoding="utf-8").read() if isArquivo else texto
    with Progress() as progress:
        tarefa = progress.add_task("Carregando...", total=50)
        for _ in range(50):
            time.sleep(0.02)
            progress.update(tarefa, advance=1)
    print(conteudo)


def progresso_lento(texto: str, isArquivo: bool = False) -> None:
    """
    Simula uma barra de progresso mais lenta.
    """
    conteudo = open(texto, encoding="utf-8").read() if isArquivo else texto
    with Progress() as progress:
        tarefa = progress.add_task("Executando...", total=20)
        for _ in range(20):
            time.sleep(0.15)
            progress.update(tarefa, advance=1)
    print(conteudo)
