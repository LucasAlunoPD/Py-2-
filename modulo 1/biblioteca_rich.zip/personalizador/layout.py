"""
Módulo layout - uso do Rich Layout para organizar conteúdo.
"""

from rich.layout import Layout
from rich.console import Console

def layout_colunas(texto: str, isArquivo: bool = False) -> None:
    """
    Mostra layout em duas colunas, uma com o texto e outra fixa.
    """
    console = Console()
    conteudo = open(texto, encoding="utf-8").read() if isArquivo else texto
    layout = Layout()
    layout.split_row(
        Layout(conteudo, name="esquerda"),
        Layout("Coluna direita estática", name="direita")
    )
    console.print(layout)


def layout_linhas(texto: str, isArquivo: bool = False) -> None:
    """
    Mostra layout dividido em três linhas (cabeçalho, corpo e rodapé).
    """
    console = Console()
    conteudo = open(texto, encoding="utf-8").read() if isArquivo else texto
    layout = Layout()
    layout.split_column(
        Layout("Topo", size=3),
        Layout(conteudo),
        Layout("Rodapé", size=3)
    )
    console.print(layout)
