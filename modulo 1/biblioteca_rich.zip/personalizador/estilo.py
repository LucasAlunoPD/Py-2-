"""
Módulo estilo - uso de estilos coloridos do Rich.
"""

from rich.console import Console

def estilo_azul(texto: str, isArquivo: bool = False) -> None:
    """
    Mostra texto em azul negrito.
    """
    console = Console()
    conteudo = open(texto, encoding="utf-8").read() if isArquivo else texto
    console.print(conteudo, style="bold blue")


def estilo_vermelho(texto: str, isArquivo: bool = False) -> None:
    """
    Mostra texto em vermelho com fundo amarelo.
    """
    console = Console()
    conteudo = open(texto, encoding="utf-8").read() if isArquivo else texto
    console.print(conteudo, style="red on yellow")
