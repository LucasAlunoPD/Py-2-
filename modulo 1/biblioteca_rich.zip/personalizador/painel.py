"""
Módulo painel - uso do Rich Panel para destacar conteúdo.
"""

from rich.console import Console
from rich.panel import Panel

def painel_basico(texto: str, isArquivo: bool = False) -> None:
    """
    Mostra painel simples com título fixo.
    """
    console = Console()
    conteudo = open(texto, encoding="utf-8").read() if isArquivo else texto
    console.print(Panel(conteudo, title="Básico"))


def painel_colorido(texto: str, isArquivo: bool = False) -> None:
    """
    Mostra painel estilizado em verde.
    """
    console = Console()
    conteudo = open(texto, encoding="utf-8").read() if isArquivo else texto
    console.print(Panel(conteudo, title="Colorido", style="green"))
