"""
Programa principal com argparse que chama funções do pacote personalizador.
"""

import argparse
from personalizador import layout, painel, progresso, estilo

MODULOS = {
    "layout": layout,
    "painel": painel,
    "progresso": progresso,
    "estilo": estilo,
}

def main():
    parser = argparse.ArgumentParser(description="Exercício Biblioteca Rich")

    parser.add_argument("texto", help="Texto ou caminho do arquivo")
    parser.add_argument("-a", "--arquivo", action="store_true", help="Indica que o argumento é um arquivo")
    parser.add_argument("-m", "--modulo", choices=MODULOS.keys(), required=True, help="Módulo a ser usado")
    parser.add_argument("-f", "--funcao", required=True, help="Função do módulo a ser chamada")

    args = parser.parse_args()

    modulo = MODULOS[args.modulo]
    if not hasattr(modulo, args.funcao):
        raise ValueError(f"A função {args.funcao} não existe no módulo {args.modulo}.")
    funcao = getattr(modulo, args.funcao)
    funcao(args.texto, args.arquivo)

if __name__ == "__main__":
    main()
