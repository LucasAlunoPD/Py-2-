# 🎮 Aventura no Labirinto  

Bem-vindo(a) à **Aventura no Labirinto**!  
Seu objetivo é explorar o labirinto, coletar itens e encontrar a saída... se conseguir!  

---

## 🚀 Como começar  

1. Clone ou baixe este repositório.  
2. Crie o ambiente virtual:  
   ```bash
   python -m venv venv
   ```  
3. Ative o ambiente:  
   - **Windows**: `venv\Scripts\activate`  
   - **Linux/Mac**: `source venv/bin/activate`  
4. Instale as dependências:  
   ```bash
   pip install -r requirements.txt
   ```  
5. Rode o jogo:  
   ```bash
   python main.py --name SeuNome --color cyan --dificuldade medio
   ```

---

## 🕹️ Controles  

Digite no terminal:  
- `w` → mover para cima  
- `s` → mover para baixo  
- `a` → mover para esquerda  
- `d` → mover para direita  
- `sol` → ativar a solução automática (o personagem percorre o caminho sozinho)  
- `sair` → encerrar a partida  

---

## 🌟 Recursos  

- Labirinto **gerado automaticamente** (nunca o mesmo duas vezes).  
- **Itens escondidos** para aumentar sua pontuação.  
- Animações e cores com a biblioteca **Rich** ✨.  
- CLI personalizável: escolha seu nome, cor favorita e dificuldade.  
- Função **recursiva** para resolver o labirinto sozinha.  
- Uso de `match-case` para os movimentos.  
- Opção para desligar sons (`--disable-sound`).  

---

## 📦 Estrutura do projeto  

```
aventura_no_labirinto/
├── aventura_pkg/
│   ├── __init__.py
│   ├── labirinto.py
│   ├── jogador.py
│   └── utils.py
├── main.py
├── requirements.txt
├── aventura_pkg.html
└── README.md
```

---

## 🎯 Objetivo  

Encontre a saída do labirinto antes de ficar sem movimentos.  
Boa sorte, aventureiro(a)! 🗝️  


---

## 🖼️ Prints de Tela (Simulação)

### Menu Inicial
```
╔══════════════════════════╗
║   🎮 Aventura no Labirinto   ║
╠══════════════════════════╣
║ 1 - Instruções           ║
║ 2 - Jogar                ║
║ 3 - Sair                 ║
╚══════════════════════════╝
```

### Labirinto em jogo
```
###########
#   @     #
#   *     #
#       E #
###########
Legenda: @ = Jogador | * = Item | E = Saída
```

### Vitória
```
✨ Parabéns, Lucas! Você venceu o labirinto! ✨
Pontuação final: 120 pontos
```
