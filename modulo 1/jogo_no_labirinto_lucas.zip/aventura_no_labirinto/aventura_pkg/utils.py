"""Módulo utils
Funções utilitárias: imprimir instruções, menu, e animações simples (recursiva).
"""
from typing import List, Tuple, Optional
from rich.console import Console
from rich.panel import Panel
from rich import print as rprint
import time

ConsoleLocal = Console()

def imprime_instrucoes(caminho_arquivo: Optional[str] = None) -> None:
    """Imprime instruções do jogo. Se caminho_arquivo for fornecido, lê o arquivo."""
    texto = None
    if caminho_arquivo:
        try:
            with open(caminho_arquivo, 'r', encoding='utf-8') as f:
                texto = f.read()
        except Exception as e:
            texto = "Não foi possível ler o arquivo de instruções."
    else:
        texto = (
            "Bem-vindo à Aventura no Labirinto!\n"
            "Use W/A/S/D para mover. Colete itens(*) para ganhar pontos.\n"
            "Chegue ao G para vencer.\n"
        )
    ConsoleLocal.print(Panel(texto, title='Instruções'))

def imprime_menu(opcoes: List[Tuple[str,str]]) -> None:
    """Imprime um menu formatado. opcoes é lista de (id, descrição)."""
    linhas = [] 
    for id_, desc in opcoes:
        linhas.append(f"[{id_}] {desc}")
    ConsoleLocal.print(Panel('\n'.join(linhas), title="Menu"))

def animacao_recursiva_vitoria(nivel: int = 0, max_nivel: int = 6) -> None:
    """Animação recursiva simples: imprime painéis aninhados recursivamente.
    Demonstra uso de recursão como requisito do trabalho.
    """
    ConsoleLocal.print(Panel(f"VITÓRIA! {'!'*nivel}", title=f"Parabéns - nível {nivel}"))
    time.sleep(0.15)
    if nivel < max_nivel:
        animacao_recursiva_vitoria(nivel+1, max_nivel)
