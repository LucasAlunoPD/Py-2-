"""Módulo jogador
Contém as funções para criar e controlar o jogador e sua pontuação.
A leitura de teclado interativa é separada para não travar testes automatizados.
"""
from typing import Tuple, Dict, Optional, List
from dataclasses import dataclass

@dataclass
class Jogador:
    nome: str
    pos: Tuple[int,int]
    pontos: int = 0
    itens_coletados: List[Tuple[int,int]] = None

    def __post_init__(self):
        if self.itens_coletados is None:
            self.itens_coletados = []

def iniciar_jogador(nome: str, pos: Tuple[int,int]) -> Jogador:
    """Cria e retorna um objeto Jogador na posição inicial com pontuação zero."""
    return Jogador(nome=nome, pos=pos, pontos=0)

def mover(jog: Jogador, direcao: str, state: Dict) -> None:
    """Move o jogador uma célula se possível.
    direcao: 'w','s','a','d' (cima, baixo, esquerda, direita)
    Usa match-case para tratar direções (exigência do trabalho).
    """
    r,c = jog.pos
    grid = state["grid"]
    match direcao.lower():
        case 'w':
            novo = (r-1, c)
        case 's':
            novo = (r+1, c)
        case 'a':
            novo = (r, c-1)
        case 'd':
            novo = (r, c+1)
        case _:
            return  # direção inválida
    # checar limites e parede
    rr,cc = novo
    if 0 <= rr < len(grid) and 0 <= cc < len(grid[0]) and grid[rr][cc] != '#':
        jog.pos = novo
        # checar item
        if novo in state.get('items', []):
            pontuar(jog, 10)
            jog.itens_coletados.append(novo)
            # remover item do labirinto
            state['items'] = [it for it in state['items'] if it != novo]

def pontuar(jog: Jogador, valor: int) -> None:
    """Adiciona `valor` pontos ao jogador."""
    jog.pontos += valor

def distancia_para_objetivo(jog: Jogador, state: Dict) -> int:
    """Retorna distância de Manhattan entre jogador e goal."""
    gr = state["goal"]
    return abs(jog.pos[0]-gr[0]) + abs(jog.pos[1]-gr[1])
