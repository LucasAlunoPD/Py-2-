"""aventura_pkg
Pacote com a lógica do jogo Aventura no Labirinto.
Contém módulos: labirinto, jogador, utils.
"""
__all__ = ["labirinto", "jogador", "utils"]
