"""Módulo labirinto
Gera e imprime labirintos. Também contém uma função recursiva de busca (DFS)
que pode ser usada como 'solução automática' do labirinto.
"""
from typing import List, Tuple, Optional
import random
from rich.console import Console
from rich.table import Table

Cell = Tuple[int, int]  # (row, col)

def criar_labirinto(lado: int = 9, densidade_paredes: float = 0.25) -> dict:
    """Gera um labirinto quadrado de tamanho `lado`.
    Retorna um dicionário com chaves: 'grid', 'start', 'goal', 'items'.
    grid é uma lista de listas com caracteres: ' ' (vazio) ou '#' (parede).
    """
    grid = [[" " for _ in range(lado)] for _ in range(lado)]
    # colocar bordas
    for r in range(lado):
        for c in range(lado):
            if r == 0 or c == 0 or r == lado-1 or c == lado-1:
                grid[r][c] = "#"
            else:
                if random.random() < densidade_paredes:
                    grid[r][c] = "#"
    # start e goal em posições vazias
    def rand_empty():
        while True:
            r = random.randint(1, lado-2)
            c = random.randint(1, lado-2)
            if grid[r][c] == " ":
                return (r,c)
    start = rand_empty()
    goal = rand_empty()
    # garantir que start != goal
    while goal == start:
        goal = rand_empty()
    # colocar alguns items
    items = []
    for _ in range(max(1, lado//4)):
        pos = rand_empty()
        if pos not in (start, goal):
            items.append(pos)
    return {"grid": grid, "start": start, "goal": goal, "items": items}

def imprimir_labirinto(state: dict, jogador_pos: Optional[Cell] = None, highlight_path: Optional[List[Cell]] = None, color: str = "cyan") -> None:
    """Imprime o labirinto no terminal usando rich Table.
    state: dicionário retornado por criar_labirinto.
    jogador_pos: posição atual do jogador.
    highlight_path: lista de células a destacar (solução).
    color: cor principal para elementos do jogo.
    """
    console = Console()
    grid = state["grid"]
    start = state["start"]
    goal = state["goal"]
    items = set(state.get("items", []))

    table = Table.grid(padding=0)
    # criar colunas
    for _ in range(len(grid[0])):
        table.add_column(width=2, no_wrap=True)
    for r, row in enumerate(grid):
        cells = []
        for c, ch in enumerate(row):
            coord = (r,c)
            if coord == jogador_pos:
                cell = f"[bold {color}]@[/bold {color}]"
            elif coord == start:
                cell = f"[green]S[/green]"
            elif coord == goal:
                cell = f"[magenta]G[/magenta]"
            elif coord in items:
                cell = f"[yellow]*[/yellow]"
            elif highlight_path and coord in highlight_path:
                cell = f"[on {color}] [/on {color}]"
            elif ch == "#":
                cell = "█"
            else:
                cell = "·"
            cells.append(cell)
        table.add_row(*cells)
    console.print(table)

def _neighbors(pos: Cell, grid: List[List[str]]) -> List[Cell]:
    r,c = pos
    candidates = [(r-1,c),(r+1,c),(r,c-1),(r,c+1)]
    valid = []
    for rr,cc in candidates:
        if 0 <= rr < len(grid) and 0 <= cc < len(grid[0]) and grid[rr][cc] != '#':
            valid.append((rr,cc))
    return valid

def buscar_solucao_dfs(state: dict) -> Optional[List[Cell]]:
    """Função recursiva que realiza busca em profundidade (DFS) para encontrar
    um caminho do start ao goal. Retorna a lista de passos ou None se não achar.
    Implementada com recursão explícita.
    """
    grid = state["grid"]
    start = state["start"]
    goal = state["goal"]
    visited = set()

    def dfs(pos):
        if pos == goal:
            return [pos]
        visited.add(pos)
        for nb in _neighbors(pos, grid):
            if nb in visited:
                continue
            res = dfs(nb)
            if res:
                return [pos] + res
        return None

    return dfs(start)
