"""Main do jogo Aventura no Labirinto
Interface de linha de comando com argparse.
"""
import argparse, sys, time
from rich.console import Console
from aventura_pkg import labirinto, jogador, utils

Console = Console()

def construir_parser():
    parser = argparse.ArgumentParser(prog='aventura', description='Aventura no Labirinto - jogue pelo terminal')
    parser.add_argument('--name', required=True, help='Nome do(a) jogador(a) (obrigatório)')
    parser.add_argument('--color', default='cyan', help='Cor principal do jogo (ex: cyan, red, green)')
    parser.add_argument('--dificuldade', choices=['facil','medio','dificil'], default='medio', help='Nível de dificuldade')
    parser.add_argument('--disable-sound', action='store_true', help='Desliga efeitos sonoros (se houver)')
    parser.add_argument('--max-movimentos', type=int, default=200, help='Máximo de movimentos permitidos')
    return parser

def escolher_parametros(args):
    if args.dificuldade == 'facil':
        lado = 7; dens = 0.15
    elif args.dificuldade == 'medio':
        lado = 9; dens = 0.22
    else:
        lado = 11; dens = 0.30
    return lado, dens

def jogo_principal(args):
    lado, dens = escolher_parametros(args)
    state = labirinto.criar_labirinto(lado=lado, densidade_paredes=dens)
    jog = jogador.iniciar_jogador(args.name, state['start'])
    movimentos = 0
    Console.print(f"Jogador: [bold]{jog.nome}[/bold] - Objetivo em [magenta]{state['goal']}[/magenta]")
    utils.imprime_instrucoes()
    # mostrar labirinto inicial
    labirinto.imprimir_labirinto(state, jogador_pos=jog.pos, color=args.color)
    Console.print("Digite W/A/S/D para mover, 'sol' para ver solução, 'sair' para encerrar.")

    while movimentos < args.max_movimentos:
        entrada = input('> ').strip()
        if not entrada:
            continue
        if entrada.lower() == 'sair':
            Console.print("Saindo do jogo. Até a próxima!")
            return
        if entrada.lower() == 'sol':
            path = labirinto.buscar_solucao_dfs(state)
            if path:
                Console.print("Solução encontrada. Executando movimentos...\n")
                # animar seguindo o path
                for passo in path[1:]:  # pular posição inicial
                    jog.pos = passo
                    labirinto.imprimir_labirinto(state, jogador_pos=jog.pos, highlight_path=path, color=args.color)
                    time.sleep(0.15)
                Console.print("Visão completa da solução acima.")
            else:
                Console.print("Não foi possível encontrar solução.")
            continue
        # aceitar apenas comandos simples ou comandos compostos como 'w' ou 'W'
        cmd = entrada[0].lower()
        jogador.mover(jog, cmd, state)
        movimentos += 1
        labirinto.imprimir_labirinto(state, jogador_pos=jog.pos, color=args.color)
        # checar vitória
        if jog.pos == state['goal']:
            Console.print(Panel := None)  # pequeno truque para evitar lint
            utils.animacao_recursiva_vitoria(0, 4)
            Console.print(f"Parabéns {jog.nome}! Você venceu com {jog.pontos} pontos.")
            return
    Console.print("Limite de movimentos atingido. Fim de jogo.")


def main(argv=None):
    parser = construir_parser()
    args = parser.parse_args(argv)
    jogo_principal(args)

if __name__ == '__main__':
    main()
